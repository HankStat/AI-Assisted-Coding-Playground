from django.db import models
from django import forms
# Create your models here.
 
class School(models.Model):
    # 學派名稱
    school_name = models.CharField(max_length=20)
    # 中心價值
    core_value = models.CharField(max_length=100)
    # 人數
    num_member = models.IntegerField()
 
class Ancient_People(models.Model):
    # 學派
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    # 名字
    name = models.CharField(max_length=10)
    # 名言
    statement = models.CharField(max_length=100)
    # 歲數
    age = models.IntegerField()

class Prompt(models.Model):
    prompttext = models.CharField(max_length=100)

class ListTextWidget(forms.TextInput):
    def __init__(self, data_list, name, *args, **kwargs):
        super(ListTextWidget, self).__init__(*args, **kwargs)
        self._name = name
        self._list = data_list
        self.attrs.update({'list':'list__%s' % self._name})

    def render(self, name, value, attrs=None, renderer=None):
        text_html = super(ListTextWidget, self).render(name, value, attrs=attrs)
        data_list = '<datalist id="list__%s">' % self._name
        for item in self._list:
            data_list += '<option value="%s">' % item
        data_list += '</datalist>'

        return (text_html + data_list)

'''class TextInputForm(forms.Form):
    text_input = forms.CharField(required=True)
    def __init__(self, *args, **kwargs):
        _prompt_list = kwargs.pop('data_list', None)
        super(TextInputForm, self).__init__(*args, **kwargs)
        self.fields['text_input'].widget = ListTextWidget(data_list=_prompt_list, name='prompt-list')
    # the "name" parameter will allow you to use the same widget more than once in the same
    # form, not setting this parameter differently will cuse all inputs display the
    # same list.'''
       


class TextInputForm(forms.Form):
    Select_prompt = (
    (0,"Write my own prompt. (use textbox below)"),
    (17,"Write a function to find the perimeter of a square."),
    (18,"Write a function to remove characters from the first string which are present in the second string."),
    (19,"Write a function to find whether a given array of integers contains any duplicate element."),
    (24,"Write a function to convert the given binary number to its decimal equivalent."),
    (25,"Write a python function to find the product of non-repeated elements in a given array."),
    (29,"Write a python function to find the element occurring odd number of times."),
    (33,"Write a python function to convert a decimal number to binary number."),
    (77,"Write a python function to find the difference between sum of even and odd digits."),
    (82,"Write a function to find the volume of a sphere."),
    )
    text_input = forms.TypedChoiceField(label='Prompt Selection',choices=Select_prompt,coerce=int,widget=forms.Select(attrs={'style': 'width: 700px;'}))
    text_input2 = forms.CharField(label='Prompt InputBox', max_length=500, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter text here', 'size': '100'}))
    
class TextInputForm2(forms.Form):
    text_input2 = forms.CharField(label='Prompt', max_length=500, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter text here', 'size': '100'}))

